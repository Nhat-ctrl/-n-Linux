# SimpleCLI-Calculator

SimpleCLI-Calculator là một công cụ dòng lệnh đơn giản cho phép thực hiện các phép tính cơ bản bằng shell script, dành cho hệ điều hành Ubuntu Linux.

## Chức năng chính
- Cộng 5 số.
- Tìm số nhỏ nhất trong 2 số.
- Tìm số lớn nhất trong n số.

## Yêu cầu hệ thống
- Ubuntu Linux
- Bash Shell

## Cài đặt
1. Clone dự án về máy:
   ```bash
   git clone https://github.com/username/SimpleCLI-Calculator.git
